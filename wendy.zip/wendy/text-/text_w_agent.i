 Friday, May 12, 2023 · 3:26 PM 
1655 Wendy  Pleasant Hill 1:15 to 2:30 saturday
 ​😠​ to “ 1655 Wendy  Pleasant Hill 1:15 to 2:30 saturday ” 
 ​👍​ to " 1655 Wendy  Pleasant Hill 1:15 to 2:30 saturday " 
 Saturday, May 13, 2023 · 5:16 PM 
Hello,

I saw the place today, it was the top on our list, and my wife really likes  to see the place,
I was wondering if you will show the place again tomorrow? If yes, then we can move forward quickly 
Please let me know, thanks 
I'm sorry I'll have to check w the current residents unfortunately  limited showings 
 Saturday, May 13, 2023 · 8:07 PM 
I understand, if only for 5 minutes, my wife can see the place, we won't bother them, and we can move forward, 
Thank you for your help
 Monday, May 15, 2023 · 8:55 PM 
Hi Ako, The application looks good but would need to have your wife also apply as she is over 18
Please let me know.   You did mention she wants to see it.  I can ask if the owner can do that
Hello Kristine,
Sure, can you please send the link, so she can apply too? 
It's on Zillow. Just the zillow app is good
 Tuesday, May 16, 2023 · 11:17 AM 
 ​👍​ to " It's on Zillow. Just the zillow app is good " 
 Thursday, May 18, 2023 · 9:29 AM 
Hello Kristine,

Just following up to see if you had a chance to look at the application and also if there is any more information that you may need,
What is yours and your wife's name?
My name is 
Ako Heidari

My wife is
Neda Mashayekhi 
also, i can email you the last two pay checks, and any more information if you need, in the meanwhile -as you mentioned-  if my wife can see the property, that would be great!
Please do and when is your wife available?                           
Anytime in the mornings would be great
Also, email or via Zillow? Which one do you prefer 
 Sunday, May 21, 2023 · 8:53 AM 
Hi will 2pm today work for seeing 1655 Wendy for your wife? 
Hi, can you do around noon?
Let Me ask them 
I appreciate it 
 Sunday, May 21, 2023 · 10:56 AM 
So sorry 2pm is their only availability 
2pm owner is Bong
 Sunday, May 21, 2023 · 12:14 PM 
 ​👍​ to " 2pm owner is Bong " 
 Sunday, May 21, 2023 · 7:48 PM 
Hi how did everything go?
 Sunday, May 21, 2023 · 9:47 PM 
Everything was good,

Just had some questions that I'll call you tomorrow
Please text me the questions tomorrow thanks
 Monday, May 22, 2023 · 12:26 PM 
Hi what time are you available today?  I'm available for any questions and also would like to know if you want to move forward
Sure, thank you for calling me, I have back to back meetings till 2, I'll call you after that
Yes, we are very interested for sure
Ok ttyl
 Monday, May 22, 2023 · 2:32 PM 
I'm free till 4, just called you
 Tuesday, May 23, 2023 · 8:04 AM 
They are ok w 400 off of first mo rent with a 2 year lease.  
 Tuesday, May 23, 2023 · 12:12 PM 
Thank you for getting back to me,

That wasn't what I was looking for,

Let's forget about that  for now,

Would you mind sending me a draft for the lease for 1 year, thanks
My email is ako.heidari@gmail.com
 Wednesday, May 24, 2023 · 12:30 PM 
thank you for emailing the lease, we have some questions before signing it,  when are you free to talk?
Available
 Thursday, May 25, 2023 · 9:42 AM 
we are ready to move forward, let's make a deal! 😌
 Thursday, May 25, 2023 · 4:17 PM 
Any updates so far? We don't want to lose the place 
We are ok w you maintaining the landscaping as you please
I'll forward  over the lease to the landlords to review and go from there
I just need a landlord verification from your landlord.   If you can send me their email or contact  info that would be great
 ​👍​ to " We are ok w you maintaining the landscaping as you please " 
Sure, can you email me what you need, I'll ask our leasing office to provide it to you
Thank 
 Friday, May 26, 2023 · 11:02 AM 
Hi I sent over landlord verification.   Please let me know when we can expect it.   
Sure, I already sent it over to my apartment management 
Thanks so much. It helps as they usually ask me for your authorization 
Any updates on the price negotiation 
The price is 4190 the landscaping can be done by the tenant yourself. 
Please do let me know if you are interested  as we have other interested parties.   Thanks
If 2 year lease they can give a one time $400 discount but are ok w year to year otherwise
Yes, we are interested, that's for sure
That 400 is more like a joke to me,
I was hoping they could be a bit more flexible, it would have been beneficial for both, 
Since just finding a new tenant and all other costs related to that would be way more than one month rent, not $400,

But it looks like they are not interested, so will see what happens,
Ok so not interested in signing at this time?  Thank you
So, yes let's move forward,
Any updates on the moving date?
We are interested 
June 15 is the move in date
Ok, all good then
I'm sorry but we are not negotiable at the price because  we have other interested parties at our price.
I understood that, 
 Friday, May 26, 2023 · 12:45 PM 
I'll call you back.
 Saturday, May 27, 2023 · 1:34 PM 
Are we good to proceed w the lease then? 
Yes, we are
 Wednesday, May 31, 2023 · 11:04 AM 
Hello,

Just checking to see if you heard back from my landlord?
 Wednesday, May 31, 2023 · 1:09 PM 
I didn't. Can you send me their phone number and I'll give them a call
 Wednesday, May 31, 2023 · 3:02 PM 
 (415) 495-4119
just google south beach marina apartments, 
 Wednesday, May 31, 2023 · 4:29 PM 
I also fwd you the email I sent them on Friday 
Spoke to them and they said they will send it back to me today
 Thursday, June 1, 2023 · 1:33 PM 
Got it will send lease today
 Friday, June 2, 2023 · 1:46 PM 
one question, hope it won't be strange, would you mind asking the landlord if they are interested in selling any of their outdoor furniture? 
Will ask now
So sorry it is already being packed for moving
 Friday, June 2, 2023 · 3:11 PM 
Thanks
 Sunday, June 4, 2023 · 9:30 AM 
Please review  the lease and disclosures.   I will be in Emeryville  today if you want to meet otherwise our office is at 4115 Blackhawk Plaza Cir #100 Danville 
Did you already send me the lease?
Yes it's sent through authentisign
Sure, I'll check it out, I can't make it today, but we will visit your office later, 
Great! Haven't checked my email yet,
Ok thanks!   Our office is open M-F 9-5
 ​👍​ to " Ok thanks!   Our office is open M-F 9-5 " 
 Monday, June 5, 2023 · 4:17 PM 
Good evening Ako,

Please review and sign lease today if still interested.  We would also need the deposit check asap.  Thank you.
Kristine Reyes Bridges Real Estate 
 Monday, June 5, 2023 · 6:10 PM 
Hi Ako,  I have responded to your email.  
Appreciate it, I'll review it and will get back to you ASAP
 Wednesday, June 7, 2023 · 12:19 PM 
Hello
I got the cashier check. Please let me know if tomorrow morning works to bring it
Sure that works how about I meet at the property would 10:30 am work? 
Yes, that's great! Thank you 
 Wednesday, June 7, 2023 · 2:01 PM 
Cleaner will be there on Friday 
 Thursday, June 8, 2023 · 10:28 AM 
Hello! We are here
 Friday, June 9, 2023 · 9:44 AM 
Good morning Kristine, 

Do we have any updates on moving dates?
I'm sorry we are only able to offer the current move in date.   The owners had relocated to Milpitas and made all accommodations for this move in date.  We also had other parties whom we could have had with our move in date and it was planned and thought of well in advance.

 Friday, June 9, 2023 · 2:12 PM 
Thanks for your try Kristina
 
Not what we expected though . It would have been a nice cooperation if they could have given us at least a week to avoid double-paying rent.

So the move will take place on June 15th, between morning and afternoon. Please ensure that the house is ready with all the necessary repairs and maintenance completed as previously mentioned. Kindly inform me of the arrangements for getting the keys, including when and how.
I have the handyman coming by today
Good 
Just please remind me if there is a microwave there? Because I can see there is one in the photo, but when we visited the place I guess the space was empty 
 Sunday, June 11, 2023 · 9:01 PM 
For the master bedroom we are removing damaged blinds.   Did you just want to put in your own curtains?  Please advise
For backyard,  the gardener is paid until end of June.  Can you please ask him to remove the weeds if you see him.   We will send over his number
 Monday, June 12, 2023 · 8:49 AM 
Please add blinds for master bedroom 
Ok I'll tell him. When he will be there?
Thanks will do 
 Wednesday, June 14, 2023 · 5:36 PM 
Good morning what time would you like to meet at the property?
Good afternoon, depends on the movers, probably around noon, or early afternoon 
I can be by early morning and the code to the lockbox is 5561.   I will leave the keys and such in a drawer for you so you can come anytime.  
 ​👍​ to " I can be by early morning and the code to the lockbox is 5561.   I will leave the keys and such in a drawer for you so you can come anytime.   " 
 Wednesday, June 14, 2023 · 9:28 PM 
[Name] Sal (gardner)
[Work] (925) 726-8009
 Thursday, June 15, 2023 · 9:05 AM 
Code is 5561 
For lockbox
Okay, thanks 👍
 Thursday, June 15, 2023 · 11:05 AM 
The garbage  company was supposed  to pick up the wood in front of the house but didn't.   I'll figure this out and get back to you
Water is still on but please apply
 ​👍​ to " The garbage  company was supposed  to pick up the wood in front of the house but didn't.   I'll figure this out and get back to you " 
Sure
Thank you
https://www.pleasanthillca.org/267/Utilities
I left the garbage out when you change garbage to your name they usually pick up the cans and distribute new cans for you
 Thursday, June 15, 2023 · 5:22 PM 
Hi 
The house was supposed to be ready for us today
But it is not 
And it's totally unprofessional as you guys promised although we offered to move in later. The yard is not clean . Still stuff to be taken out. 
The handyman already removed the items
I told you he was coming this afternoon
Sorry for any miscommunication 
 Friday, June 16, 2023 · 10:58 AM 
I'll get back to you in regards to the repairs.   The handyman mentioned he showed the toilet  and it was OK?   Please confirm we paid for this repair already
For the cleaning the owners paid for a professional cleaner.  The items you wanted clean were  the sink in garage and there is lint in the dryer? Those seem minimal and can be done.  The garage sink may have staining.  
One bulb needs replacement if you can please send me a pic of the bulb so we can replace. 
The bulbs need changes are attached in the emails 
I'm sure the house is not cleaned by professional by any means . Have you seen the photos? Like under the oven drawer? it's still full of items and dirt. And also ac vents and more stuff 
We have a small baby as you know and we need to settle the house as soon as possible. So please consider resolving issues asap
And also I really do appreciate communication via email
 Friday, June 16, 2023 · 12:32 PM 
I appreciate you being there to help us,

Unfortunately, the house is not clean by any stretch of imagination, I wonder even if it's been cleaned in a long time,

Just look at this photo from the top of the kitchen and judge for yourself is it's clean? 
And this is the washing machine 
I really hope it's only dirt and mold
I can show other issues to the handyman 
If that's fine with you
Top of the counter may have been me.   Either way I'll ask the owner and I can have my cleaner there. 
Or I can have a cleaning service here and send the bill. Let me know which one works best 
I have to get approval from owner for any amount over 300 
I normally get approval for any work 
Ok. I can offer to pay some of it if it makes things go faster. 
The cleaning service I meant 
Owners spent 800with their own cleaner already  so they are asking them to come and clean missed items
All good, please let me know when they will be coming
 Friday, June 16, 2023 · 2:51 PM 
Would you happen to know the passcode for the security system? 
Asking owners 
 ​👍​ to " Asking owners  " 
Btw, is the trash included or should I start it in my name?
It is not included as to be in your name.  It is on the utilities list https://www.pleasanthillca.org/267/Utilities
Working on it right now 
And with PGE, it will include the nature gas as well? Or do I need a separate account?
Yes it includes gas
The alarm will go on in 120 seconds 
Still waiting 
Can't leave the house? Or let any one in? 
 9999
 ​👍​ to " 9999 " 
 Saturday, June 17, 2023 · 3:21 PM 
Just wanted to say thank you, you have been doing great so far! 
 Saturday, June 17, 2023 · 8:00 PM 
What's the deal with the security system? Should I call somewhere?
 ​👍​ to " I left the garbage out when you change garbage to your name they usually pick up the cans and distribute new cans for you " 
Let me ask.  
 Saturday, June 24, 2023 · 10:17 AM 
Hello!
Do you think you will be able to stop by here sometime?

Also, the Gardner is asking me for money, while you said he was paid, do you mind clarifying it?
He was paid til end of June 
I'll clarify w him
 ​👍​ to " I'll clarify w him " 
 Tuesday, June 27, 2023 · 1:19 PM 
thanks for clarifying it, 
btw, when is a good time for a quick call
 Tuesday, June 27, 2023 · 3:44 PM 
Just some technical questions, about setting up the rent payment and solar...
Can you please text it as I have to relay the message to the owners and they are not in the country
 Wednesday, June 28, 2023 · 12:41 PM 
Sure, this one is not that official, so I'll text it to you here,
The more serious one will be emailed 
12:41 PM
· SMS
1- I paid the rent, and this is the attachment, it looks like the only way to make that payment is to either have a chase account, or go to the branch in person,
2- I want more information about solar, is it connected to pge account or not,
Should I follow it up or the landlord wants that to be taken care of,
3- for the security system, is there a monthly payment for that? Should I take care of that, or is it all good?
I don't like surprises with a bill
4- apparently, the landlord didn't stop any utility services, like water, trash PGE,
I'm taking care of it one by one, but if there is anything that's currently going on, please let me know, because I don't want to be responsible for a service that I wasn't aware of,
 Wednesday, June 28, 2023 · 2:03 PM 
Hi I sent them the list and asked them to turn off.   I will ask again. 
1.  Thanks for the payment
2.  Solar is usually already attached to the property.
3.  Asking owner and will get back.
4.  Water, Trash and water and cable is what I can think of
Sorry I am not in a place I can speak
2-The solar is not connected to PGE,
That one needs to be clarified ,
3- I'm fine with security system, just need more information about the possible price
4- we got our interi, hopefully they have cancelled their own,
Also we are not using cable,
So hope that is also been taken care of 
The urgent one is about the refrigerator and freezer, I don't know if you saw the email, but that is a serious question, I need to talk to you about it
 Thursday, June 29, 2023 · 4:33 PM 
Thank you Kristene for sending Henry,
Also the guy was here to check the refrigerator, he said it will take a week to fix it, 
It looks like the fridge is done
It's a $1200 repair
Per lease the fridge is a personal item.   I can have the seller pay for removal or normally if you purchase your own,  the installer will remove the fridge for you. 
 Thursday, June 29, 2023 · 8:04 PM 
Are you confirming that the landlord is refusing to repair the fridge?
It's not worth repairing 
I've messaged them and let them know what the lease states as well. 
 Friday, June 30, 2023 · 8:13 AM 
Do they have any plans to purchase a new fridge?
If not please send someone to remove this one . 
 Friday, June 30, 2023 · 1:00 PM 
I have someone who can removr
Today afternoon or tomorrow  morning works
Please advise
Tomorrow morning 
Bernardino will be there around 10:30 to 11am
 Saturday, July 1, 2023 · 10:06 AM 
Mprny
We'll be heading out at 11 . Hope the guy will be here before 
Morning**
Ok
 Wednesday, September 27, 2023 · 9:57 AM 
thank you for sending the gentleman to take care of the water leak, 
i have two minor requests, 
1- if that's possible, please share a receipt or some other documents that the water leak has been taken care of, by providing that to the county, I may be able to lower the bill, 

2- (not urgent) there were two small issues with the water leakage that may have been left, or I may have forgotten to mentioned, if there was a chance to take care of that in the future, that would be great too!
 Wednesday, October 4, 2023 · 10:40 AM 
Update:

Thanks again, no need for receipt, I took care of it,

For the gopher issue, I won't mind it, but I was told it could be difficult to get rid of, and also it's already damaging the lawn, so please advise me if you want to take care of it or you don't mind it making holes in the backyard, (not urgent)

The leak is still Happening in the backyard, so please plan to have it fixed,

And also, the county mosquito control was here for the gopher and other issues, they recommended blocking some holes around the house to prevent rat or mouse coming to the house again,
It looks like there was a dead rat in the attic, and one currently in the A/C system in the backyard, also two issues with the entrance through the roof, near the same area,

I have the pictures and recommendations from the county as well if needed,

It was a long text, so thank you again!
 Wednesday, October 4, 2023 · 1:02 PM 
 ​👍​ to “ Update:

Thanks again, no need for receipt, I took care of it,

For the gopher issue, I won't mind it, but I was told it could be difficult to get rid of, and also it's already damaging the lawn, so please advise me if you want to take care of it or you don't mind it making holes in the backyard, (not urgent)

The leak is still Happening in the backyard, so please plan to have it fixed,

And also, the county mosquito control was here for the gopher and other issues, they recommended blocking some holes around the house to prevent rat or mouse coming to the house again,
It looks like there was a dead rat in the attic, and one currently in the A/C system in the backyard, also two issues with the entrance through the roof, near the same area,

I have the pictures and recommendations from the county as well if needed,

It was a long text, so thank you again! ” 
Thanks
Let me have bernardino  come back again in regards to the leak
 Thursday, October 5, 2023 · 9:28 AM 
Bernardino will be there today 
 Thursday, October 5, 2023 · 1:10 PM 
We are not home, but he can go to the backyard,
The leak is near the big tree
 Friday, December 1, 2023 · 4:25 PM 
Hi,
Just found out I've run out of checks,

Is there any other way that I can pay the rent?
Zelle,
Venom,
Or...
 Saturday, December 2, 2023 · 10:32 AM 
Checking w the owner
 ​👍​ to “ Checking w the owner ” 
 Saturday, December 2, 2023 · 1:00 PM 
Thanks
Happy holidays!
Happy holidays to you too 🎈
 Monday, December 4, 2023 · 9:30 AM 
Would you mind  forwarding this to the landlord 
I hope this message finds you well. I wanted to reach out and sincerely apologize for the delay in this month's rent payment. I've encountered an unexpected issue with Zelle's transfer limits and have been working to resolve it.While attempting to send the rent, I discovered that Zelle has a cap on the amount that can be transferred at once. To circumvent this, I tried distributing the funds across different accounts. Unfortunately, this solution hasn't worked as smoothly as anticipated.
I'm currently on my way to Chase Bank to explore alternative ways to ensure the rent is paid as soon as possible. If necessary, I'm also prepared to open a new account to facilitate this payment.
I deeply regret this inconvenience and assure you it won't happen again. Your understanding in this matter is greatly appreciated. I'll keep you updated and confirm once the payment has been made.Thank you for your patience and understanding.

Best regards, 
Ako
Thanks for the update
 Monday, December 4, 2023 · 2:33 PM 
I went to Chase, but couldn't open a bank account because of my immigration status,

I sent 1000 via Zelle,
And the 3190 tomorrow morning,
Sorry for all the delay 
 Monday, December 4, 2023 · 3:50 PM 
No worries thanks for the update
 Wednesday, December 6, 2023 · 8:19 PM 
Hello again,

I sent the money via 3 different transfer via zelle, just wanted to ask if you don't mind check with the landlord if she received it,
1- Zelle via federal credit union----> $1000
2- Zelle via Capital One ---> $2500
3-Zelle via federal credit union----> $690
i feel very bad for what happened and I will make sure I will pay the upcoming rent ahead of time, sorry again for all the inconveniences 
 Thursday, December 14, 2023 · 10:47 AM 
Hi,
I think there is an issue with the plumbing in the house,

We smelled the wastewater and also there were some blobs from the kitchen sink and toilets - which were strange -

I'd appreciate it if you could take care of it, thanks
 Wednesday, December 27, 2023 · 12:24 PM 
Hello Kristina,

hope you are having a great holidays,

we tried to use the fireplace, but looks like it was having some issues in the chimney, so if you don't mind would you ask the landlord when was the last time it was cleaned? and if it's been more than a year, can you send some one to investigate or clean it? thanks!  
 Wednesday, December 27, 2023 · 7:01 PM 
Let me ask the owners
 Thursday, December 28, 2023 · 10:22 AM 
 ​👍​ to “ Let me ask the owners ” 
 Thursday, December 28, 2023 · 3:30 PM 
Per owners
It was cleaned a year ago then used it 2 or 3 times only
 Saturday, April 13, 2024 · 6:42 AM 
Private chat with Kristine. 
Details
Good morning,

There is water leaking from the skylight, if you can manage to send someone quickly, it would be appreciated 
2261.mp4
 Saturday, April 13, 2024 · 9:36 AM 
Hi so sorry who is this and what property?
Hello! This is Ako,
My new number,
1655 Wendy Dr 
So sorry I didn't save it
 Saturday, April 13, 2024 · 11:10 AM 
Oh, okay 👍
 Saturday, April 13, 2024 · 12:22 PM 
Hi I've called several places but most are closed or can come on Monday.   Henry can make it on Tuesday which I will book
Sure, it's stopped at the moment, so no worries 
Supposed to have rain this evening 50 or 60 percent chance.  I also don't think they come and look at roofs during rain or wet due to safety reasons
👍
 Wednesday, April 17, 2024 · 11:12 AM 
Hi Ako,

We have prepaid HVAC maintenance we would like to have scheduled.   What days and times are good for you?   Also you are welcome to schedule it 925-778-1415.   FRESI service experts
Let me know.  Thanks,
Kristine Reyes Bridges Real estate
👍
 Wednesday, April 17, 2024 · 2:23 PM 
Sure, let me check and we'll get back to you,
BTW, there is an alarm on the AC to change the filter,
I didn't know if I can do it or if I should ask Henri,
 Wednesday, April 17, 2024 · 10:53 PM 
I think you can ask the ac maintenance person
 Thursday, April 18, 2024 · 11:41 AM 
So, if I understood correctly, I can contact this HVAC maintenance for the filter, Right?
Yes
Can you please schedule the maintenance ?   Let me know when you do?
Sure!
I called and scheduled it for tomorrow, 

They just asked if I'm Mr. Perez, and I said no! 
So they asked you to contact them and make sure if they can use the credit card on file, 
Mr. Perez and the text said it was a prepaid service
I know
They just weren't sure if they can continue to use the credit card on file,
I tried to explain it, but with no lock
Luck*
They thought you meant that you were the new home owner so they removed Mr. PEREZ'S credit card info.  They say you are still set for tomorrow for the service 
I tried to explain that I'm renting and you are the agent and I'm not the owner, but she didn't understand or didn't want to listen
Anyway, thanks for taking care of it
 Thursday, April 18, 2024 · 3:46 PM 
No worries I tried explaining the same thing 
Let me know how it goes
 Friday, April 19, 2024 · 11:15 AM 
Kindly ask technician to check storage at the back of the house for a filter. The owner says he  might have an extra there
Sure! We actually did, but couldn't find any
No worries the landlord asked them to replace
They charged 150 for the filter itself which is over double the price.  
Oh! I didn't know
The water heater I think you can adjust the temperature 
I could have bought one if I knew it's the case
I think they showed me something at the back that was really stained, but I honestly don't know,
Maybe Henri could do those things so it will be more cost/effective 
Or, I can take care of some of those maintenance and share the receipt with you, 
https://www.google.com/search?q=how+to+adjust+the+temperature+on+a+hot+water+heater&oq=how+to+adjust+the+tem&gs_lcrp=EgZjaHJvbWUqBwgBEAAYgAQyBggAEEUYOTIHCAEQABiABDIHCAIQABiABDIHCAMQABiABDIHCAQQABiABDIHCAUQABiABDIHCAYQABiABDIHCAcQABiABDIHCAgQABiABDIHCAkQABiABDIHCAoQABiABDIHCAsQABiABDIHCAwQABiABDIHCA0QABiABDIHCA4QABiABNIBCTExMzMzajBqNKgCALACAA&client=ms-android-att-us-rvc3&sourceid=chrome-mobile&ie=UTF-8
If it has a dial you can just adjust with that
I had done that actually,
I don't think that was the issue
My impression was that the pipe has stains on it and it may break any time, but that's all up to you
BTW, it's less than two months remaining in the lease,
Are we all good to renew it?
 Tuesday, June 18, 2024 · 1:02 PM 
Hello Kristine,

I hope you are doing well. I wanted to inform you that we caught two mice this morning in our house. I am a bit concerned as it raises significant health concerns for us.

As you might remember, I had previously mentioned the dead in the antiques and the holes in the garage, which I believe are entry points for these rodents. Unfortunately, handling these issues is beyond my capabilities, and I would greatly appreciate the landlord’s assistance in addressing them.

I have consulted with two rodent control experts, and while I am prepared to take immediate action, I understand that it might be best to wait for the landlord’s decision on how to proceed. I certainly don’t want to impose any extra costs or inconvenience, but ensuring a safe and healthy living environment is important for us.

Thank you so much for your attention to this matter. I look forward to hearing from you soon.

Best,
Ako
 Wednesday, June 19, 2024 · 7:31 PM 
Hi Ako,   I can have a pest removal company come.   I'll call and schedule  tomorrow.  They usually will have 3 appointments  first for seeing entry points.   2nd for blocking entry points and 3rd for making sure their repairs have worked.  
That's great, I appreciate it 
 Friday, June 21, 2024 · 10:02 AM 
Which company is it? Someone is here, but I don't think they are from you
No I haven't gotten anyone.   What is your availability 
Hi will Tuesday at lunch work? 
Anytime before 11:30 or after 2:30 will work
Ok let me reset it thanks 
They can do 2:30 on Tuesday
Hi what was the outcome w the 2 rodent control companies? 
Yes sure!
One gave me a quote, 
Can you please forward to me kristinejreyes@gmail.com 
👍
 Friday, June 21, 2024 · 4:05 PM 
I forwarded it
Did you receive it?
 Monday, June 24, 2024 · 7:57 PM 
So, are we confirmed for tomorrow at 2:30? 
My daughter is a bit sick and I'm also in the city for a conference 
Should I cancel?
 Reschedule?
No just asking if it's fixed
So, do they need us to be home? 
My wife can show the garage and pantry, 
Yes ok
Thanks
 Wednesday, June 26, 2024 · 4:20 PM 
The inspector was here yesterday, 
He mentioned he will give his advice to you
In the meantime, we caught the third rat on Monday 
I'll check his quote now.  And ask the owners which company they prefer
👍
4:21 PM
 Thursday, June 27, 2024 · 1:56 AM 
I think for a start we may ask Henry to do the minimum - which is blocking the access from the garage to the pantry- probably a bit easier 
 Thursday, June 27, 2024 · 8:12 AM 
Henry is out til July 23 but my other handyman is available and will be back on Monday.  
👍
 Monday, July 1, 2024 · 8:50 AM 
Hello! Hope you had a good weekend! 

Just checking to see if your handyman will be here today? 

Thanks
 Tuesday, July 2, 2024 · 8:01 AM 
Please act on this matter immediately. As soon as today. 
The problem is serious and it’s been weeks! 
These photos are from this morning. 
Mouse droppings are everywhere in the garage and pantry. Our daily life in the house is affected by this matter.
 Tuesday, July 2, 2024 · 3:04 PM 
Would have been nice to at least confirm receiving the text and informing me if you are going to take action or not.
 Tuesday, July 2, 2024 · 7:00 PM 
Hi so sorry I've been in meetings today and leaving to travel.   I've messaged the landlords.   I agree to get the patches done.  Let me call them to get a response
👍
 Wednesday, July 3, 2024 · 3:42 PM 

Hi 
This is an automated message system. Please call our office with any questions or concerns.: (209) 407-2040Hi Ako, this is Pro Active Pest Control with a limited time offer of additional $30 off your first service on a Pro Active year round service! Offer ends tomorrow! Call 888-674-9095 to schedule
This is the first and the second message
Please let me know if you want me to call them or you will move forward on your end
Also,
I can make the agreement and payment if that can help too 
 Wednesday, July 3, 2024 · 7:13 PM 
Can we get the payments and what is to be done?   
Sure, 

Would you mind explaining a bit more?

Is this the question for me or the company?
1.   Actions and frequency to be performed?

2.  Cost, how many times per month?  How many times do they recommend treatment? 

3.  Any other actions needed to be performed and not covered by the company? 
Questions for the company. I'm happy to email them.   Can you give me the company name? 
 Thursday, July 4, 2024 · 8:32 AM 
Sure, 
As much as I remember,

It was a one initial fee,
And then regular check 

And I think sort of guaranteed, 

With around 50 per month 
I'll check it and will send it to you ASAP
 Monday, July 8, 2024 · 10:07 AM 
Hello! 

I sent the email and text to the company to give me the agreement or a new quote,

Also, 
1- is the handyman going to be back today to fix the holes?

2- it looks like the AC needs a bit of maintenance or check,
I remember there was an agreement with a company for this,
So, would you please contact them or should I schedule it directly? Please let me know, 

Thanks!
 Monday, July 15, 2024 · 10:11 AM 
Good morning, Kristina,

I understand that there is not much you can do without the landlord’s permission. However, it is unacceptable that he is not addressing the issue we are dealing with. There must be something that can be done to help us out.
Please fwd this text to her as I don't have any direct access
Hello,


I hope this message finds you well. I am writing to follow up on the ongoing rodent issue at our rental property, specifically in the garage and pantry. As we've previously discussed, we have encountered and caught several rats so far.

We appreciate the efforts that have been made, but unfortunately, the problem persists, and it's been over a month without a definitive resolution. We want to stress the importance of addressing this promptly not only for our comfort but also in compliance with California Health and Safety Code, Section 17920.3, which emphasizes the need for rental properties to be free from vermin.

We kindly urge immediate action to remedy this situation. Ensuring the property is safe and habitable is crucial, and we are aware of our rights under this and other relevant health and safety regulations. We're confident in your ability to resolve this matter efficiently.

Thank you for your attention to this urgent issue.

Best regards,
Ako

We saw the option from the $1020. Would this include patching and fixing the issues for the pantry and laundry area? 
The landlords want this resolved 
The quotes you have gotten do they include blocking the areas to prevent the rodents?
This is what I have from handyman

Here is estimate for fix holes in garage and laundry room dry
1. What did he just stand left? I need to be blocked with the plywood. 
2. Need to feel holes  corner right inside drywall. 
3. Inside the laundry room need to fix the drywall.
4. In garage ceiling need repair.
5. Side garden entry door in garage under the door need to be filled the cement.
6. Under the sink in garage drywall need to be fixed.
For in total is 1650 .
 Monday, July 15, 2024 · 12:02 PM 
Hi Ako,  the landlord is sending his own handyman to do the work.    Can you please send pics of the holes needing patching.   He is aware got he laundry room hole.  If there are others please send us pics
Also when would. You be available for them to do the work? 
For the exterminator we can get the monthly exterminator for a few months and see if the problem is resolved.  
 Monday, July 15, 2024 · 1:46 PM 
Hello there. Yes. I will email everything again.

To answer your question. We do not seal any holes inside the house. We only see all the holes on the exterior. These rodents are entering the house from the exterior entry points. Any holes inside the house, if they are being blocked, rodents can easily chew right next to it to enter again.

We are a five star company and will take great care of you. I have been doing this for almost 10 years, I can definitely guarantee and warranty this service.
The landlord wants to have his handyman there on Wednesday 
Sure, all good
 Monday, July 15, 2024 · 3:55 PM 
It's an screen shot
I sent the pics via Whatsapp 
Hi the owner only authorized 1k.  
This seems high and the owner is having his handyman do the work for the patching
The monthly payment for 50 to 100 a month is ok
Sure, 

I think we are on the same page,

So let me explain 
That's the quote for the entire house to be taken care of,

-- which obviously we are not going to pay that much--
Just sharing the price that I was quoted,

Right, so that's not the concern, we are good here
That's the maintenance that I already had emailed,

100 first,
Then 50 per month, 
 Wednesday, July 17, 2024 · 10:50 AM 
What's the ETA for the handyman today?
 Wednesday, July 17, 2024 · 1:26 PM 
?
Hi sorry the landlord was supposed to set up 
I'll message now
Hi i spoke to the contractor it is at 4pm today he is coming by to see what materials need to be purchased  and will schedule to do the work tomorrow or Firday.  
Friday
Will that work?
Sure, thanks
 Thursday, July 18, 2024 · 8:38 PM 
Ed will be back tomorrow around 10 to 11 to finish the painy
Paint
 Thursday, July 18, 2024 · 9:43 PM 
Sure, 
And I should mention that they did a great job!  well done! 
Great!
He's a licensed contractor 
 Wednesday, September 4, 2024 · 5:30 PM 
Hi Ako,   Checking on the rent as the owner says he hasn't received it yet.  Please advise.  Thanks
 Wednesday, September 4, 2024 · 11:00 PM 
Hello Kristine,

Yes, unfortunately I haven't been able to make the payment on time,
***
I have ongoing financial difficulties, but I'm trying to resolve the issue ASAP.
Also,  i will pay any late fee that might be necessary,
***

So, please send my sincere apologies to the landlord and let him know that I'm doing everything I can to make the payment.

In the meantime, if there are any possible options available, please let me know


Thanks,
Ako
Hi when do you think you will have the rent?
Or do you have part of it?
I'll pay the first half by September 10th, and the rest by the 15th,
That's what I'm trying to do
Is this going to work with them? 
Hi Ako,   I'll talk to them thanks for communicating with me.   I'll call you tomorrow.
👍
 Friday, September 6, 2024 · 10:00 AM 
Any updates here?
 Sunday, September 8, 2024 · 9:35 AM 
Hi Ako,   the owners didnt receive anything you mentioned you were swnding half and the other half by the 13th?   Please advose
 Sunday, September 8, 2024 · 10:56 AM 
Hi Kristine,

Probably there was probably a misunderstanding here,

We spoke on Thursday and I was trying to say that next week I'll make payments,

One earlier next week and the rest before Friday 
So, I received part of the  money from a friend and it will be on my account in the coming days, so should be resolved soon
 Tuesday, September 10, 2024 · 12:50 PM 
Hi, 
Just made the full rent payment,

Sorry about the delay
Thank you.    Will we be ok w October? 
I hope you're doing well. Again, I sincerely apologize for the delay in paying the September rent. Unfortunately, I've been unemployed since June, and while I've made it a priority to meet my rent obligations, it's been challenging. I’m actively job hunting and have been to the final rounds of interviews on several occasions, though I haven’t secured a position yet.

At this point, I'm unsure if I'll be able to pay October’s rent on time. Is there any possibility to discuss a payment plan or an extension for this month? I’m doing everything I can to get back on track and hope to have a job soon.

Please let me know if you need any additional information from me. I will keep you updated as the situation develops.

Thank you for your understanding, and I appreciate your patience during this difficult time.

Best regards,
Ako
 Thursday, September 12, 2024 · 12:34 PM 
The air filter company is calling me again and again for some balance on the file,
And they haven't changed the air filter ( except just once)
If u want to contact them or just cancel it, please do so,

Thanks
Hi can i get their info?
Good afternoon, this is Trey calling with frisky Service Experts. Just giving you a call because you just have a new balance on your account, and we would like to go ahead and get that squared away for you. So that's really as convenient. Please give us a call back at 925-778-1415 so we can add a payment method on file for you. Thank you. Have a nice day. Bye.
Hi Ako, 

We are ok to waive the late fee for September but will be charging a late fee for any other future late payments. 
That's very kind and I appreciate it,
Thank you 
 Friday, September 13, 2024 · 3:30 PM 
The lady from the service called again, 
She mentioned that she has tried to call you and left you multiple voicemails, but haven't heard back
And the account is past due, 
So, just wanted to let you know and if I can do anything to help, let me know

Thank you 🙂
Maybe paying for this and overdue amounts, and later deducting it from the rent, 
Or however it is convenient for you, 
If it's not, then it's totally understandable 
 Saturday, September 14, 2024 · 8:40 AM 
Hi the owner is taking care of it.  So sorry for the disturbance to you.   I told them to remove you from contacting as the owner has a direct contract w them. 
 Tuesday, September 17, 2024 · 10:14 PM 
Sure, no worries, just wanted to help
 Monday, September 23, 2024 · 12:43 PM 
I just received an official job offer, so hopefully we will be on track pretty soon 
Congratulations  Ako!    
👍
Also I need to do a walk though of the property and check property condition.   Are you available  this week?
Sure, all good with us
I'm heading to Brentwood this evening at 5pm possible to see it before or after? If not Wednesday would ne good for me
Sure, see you then
 Thursday, October 10, 2024 · 2:41 PM 
Hello again! 

We had an issue with the faucet at the bathroom, 
Also when your husband visited I informed him, 

Would you mind taking care of it
2826.mp4
Hi Ako got it.   Sending over to henry to review thanks for the video
👍
 Tuesday, November 12, 2024 · 10:50 AM 
Hello Kristina,
Hope you're doing well,

The air company is calling again,

Also, I'd like to see if there is an update on Henry's plan to fix the issues,

Thanks
 Wednesday, November 13, 2024 · 4:59 PM 
And this is my daughter's room, the window had issues since we moved in, appreciate it if you could fix it, as it's getting cold
Got it
Sorry was it hard to close?
Anything in track?    Not fitted properly? 
It can't be fully closed so we covered it with duct tape for now
I might say it's not fitted properly 
But not sure 
 Friday, November 15, 2024 · 8:41 AM 
I'm not sure what does it mean, but I got this alarm several times last night 
I'll ask the owner who is this from?   Has your heater shut down unexpectedly? 
I didn't notice anything, but I got the alam,
From Google home and the heater as well
Can you try the trouble shoot  link?
 Friday, November 15, 2024 · 10:50 AM 
I'll
 Monday, November 18, 2024 · 9:43 PM 
Was heater ok?  1.  Faucet needs repair
2.  For the door in daughters room let me ask if the handyman can do an easy fix
 Tuesday, November 19, 2024 · 5:51 PM 
Didn't see more warning from heater, so hopefully it's ok

2- sure, thanks
 Wednesday, November 20, 2024 · 8:39 PM 
Please keep me posted for the repair planning,
It's leaking very much (faucet)
And my daughter's room is cold and noisy
 Tuesday, November 26, 2024 · 12:36 AM 
Thanks
 Tuesday, November 26, 2024 · 3:01 PM 
 Tuesday, Jan 14 · 1:45 PM 
Hello Kristine,
Hope you had a good holiday, 

A couple of points that I wanted to share with you:

1- the air service called again for a balance on the account, 😕 

2-if you  recall the landlord approved a monthly payment for $55 for pest control,
I have been paying for it but didn't deduct it from the rent,
Going forward I wanted to check if I can deduct it from now on or we should wait till the end and maybe deduct it from the last month,

Either way would work, just wanted to see how the landlord prefers it
Yes please deduct from rent also the previous payments can you please forward over the invoice for the pest control.  
Hi I called the and advised them to call the owner 
👍
 Saturday, Feb 1 · 10:15 PM 
I received this mail, I think this maybe important, 
 Tuesday, Feb 4 · 12:43 PM 
I can return the mail, or discard it
also, for the pest control, it's $55 per month, so far totalling 5*55 + 69 = 344
i made this month rent payment in full, but from the next month, I can deduct it, either all at once, or on a smaller fractions, please let me know
 Tuesday, Feb 4 · 2:11 PM 
Hi I'll let the owners know
If we are no longer having any pest issues,  can we discontinue service? 
Thanks
If you recall, this was a one year contract, otherwise it would have been more expensive 
 Tuesday, Mar 4 · 11:07 AM 
Any ETA on the window repair?
😐
It's actually for this month
359
So, the rent would be 4190 - 359=3791
 Saturday, Mar 15 · 12:33 PM 
Hi lease renewal.is coming up and wanted to know if you were interested in renewing? 
Renewal | Employee Benefits Advisors & Group Insurance Brokers
Renewal | Employee Benefits Advisors & Group Insurance Brokers
Renewal makes employee benefits easy—helping you navigate plan options, implement cost-saving solutions, and educate your employees.
www.renewal.is
 Sunday, Mar 16 · 4:12 PM 
Hello,

Yes! Thanks for the reminder,

I will need a week or two to make the final decision, but I'd say we are interested,

BTW, we are still waiting for the bedroom window repair,

And also the padio roof was damaged as well, because of the heavy wind,
 Sunday, Mar 16 · 6:09 PM 
Thanks for letting me know
 Friday, Apr 4 · 6:37 AM 
Hi Ako,   


The landlords have decided not to renew and are wanting  to sell the home.   Do you have any interest in purchasing?
For March rent I believe you said it would deduct 344 but looks like 359 was deducted Please send invoice when you can thanks
 Friday, Apr 4 · 1:17 PM 
Hi Kristene,

Thank you for getting back to me, 
That's unfortunate to hear, hope everything is going well, 

For purchasing, where can i get some info?
Let me check, I'm not sure if it was a calculation mistake or not,
Right, 
Looks like it was my mistake?
I'll add 15 for this month,
All good?
 Saturday, Apr 5 · 3:54 PM 
I haven't received anything yet
Also I wanted to check how serious this case is,

Should we start looking around? Because we want to stay here if that's an option 
🚯
Hi move out would be June 15.   
I also reached out to an investor possibly interested in purchasing with tenants in the property.  
Let me know when you are available to talk
Sure, not today, maybe Monday
 Saturday, Apr 5 · 5:33 PM 
That sounds reasonable, and it can work for us as well,
***
In the meantime if you happen to know a place similar to this one ( remodeled kitchen, 2-3 bedrooms) in the area (Pleasant Hill, walnut Creek, Lafayette) 
Please let us know! 
Thanks
 Saturday, Apr 5 · 6:34 PM 
I will does the purchasing not work for you at this time?  
 Saturday, Apr 5 · 10:00 PM 
No, unfortunately at this time
 Monday, Apr 7 · 1:08 PM 
I'll be available for a can today till 4 pm if that works for you
Please let me know
 Friday, Apr 18 · 7:30 PM 
Would you mind giving us some clarification on the lease renewal situation, and possibly when you may get confirmation from the potential buyer?
Hi Ako,  the landlord doesn't want to renew and will sell the home.   I will send over a mutual cancellation  to sign
Okay
Thanks
And if you happen to have a similar property for rent nearby please let us know,
Appreciate it
 Wednesday, Apr 23 · 5:38 PM 
Texting with Kristine
Hello Kristine,

 thank you for letting me know. I understand the landlord’s decision, but I wanted to ask if there’s any chance they might reconsider renewing the lease for another year. My daughter really loves this home—we celebrated both her 1st and 2nd birthdays here, and it’s become a special place for our family.

If there’s anything I can do to help make an extension possible—whether adjusting lease terms or rent—I’d be happy to discuss. We’d truly appreciate the opportunity to stay a little longer.

Best regards,
Ako
Private chat with Kristine. 
Details
 Monday, Apr 28 · 6:50 PM 
Hi Kristine Can you please share w/ the tenant that we need to revise the time for Wednesday? So the time we will be there are:



Wednesday 4/30: 1-3:30

Thursday 5/1: 10-12:30? 



We're including home inspection etc so we need to extend hrs thanks .
Hi Ako,  will this time work for showing.  The owners want to keep the date for move out to June 15. 
 Monday, Apr 28 · 8:13 PM 
Hello Kristine,
Sorry to miss your call 
Let me double check with my wife and will get back to you
I'd say probably Wednesday might be better than Thursday, but please wait for the confirmation 
Also, Can we please get the cancellation signed?  
I emailed it over I  can resend.  Thanks
 Tuesday, Apr 29 · 3:09 PM 
The schedule will be:
Wednesday 4/30: 
• 1:30-2:30: John home inspection
• 2: Brandi from Woodiwiss painter

Thursday 5/1: 
• 10:30-11:30: Ashley staging
• 10:30: Mike the pest inspection
• 11: Sammy the painter
Please confirm this works
 Tuesday, Apr 29 · 5:49 PM 
Hello Kristine,

Thanks for reaching out. I just wanted to let you know that the dates you mentioned for the showing—especially Wednesday and Thursday—won’t work for me, since I won’t be home those days. Monday or Tuesday would be the only days that work on my end.

Also, I haven’t had a chance to go through the mutual cancellation yet. Things have been really hectic, and I won’t be able to get to it over the weekend. I’ll need a bit more time to review it properly.

Thanks for your understanding—please keep me posted.

Best,
Ako
 Tuesday, Apr 29 · 7:23 PM 
Will you be home today or tomorrow?  I will need to serve a termination of the leade if the mutual cancellation doesn't work for you
Termination of the lease
Would it be ok for us to enter the premises without you there? 
The landlord is on his way here and doesn't have another time
Right now?
Per lease we are supposed to give 24 hour notice
I am happy to be there if needed
Yes, 
If you could be here, that would be nice, 
Thank you
Thanks will do.  
Confirming it is OK as we need entry
Yes, it is
Great!
The schedule will be:
Wednesday 4/30: 
• 1:30-2:30: John home inspection
• 2: Brandi from Woodiwiss painter

Thursday 5/1: 
• 10:30-11:30: Ashley staging
• 10:30: Mike the pest inspection
• 11: Sammy the painter
It seems like we didn't have another choice, 😕
So sorry I tried to make it so that it's not too bothersome for your family.  
They have only 2 days and within a time period is. Several days
Versus several days
 Wednesday, Apr 30 · 1:34 PM 
415 760 4408
 Wednesday, Apr 30 · 9:09 PM 
Hello Kristine,

Thank you for stopping by here today, 

I hear that your family wasn't feeling that well, hope everything will be better soon, 

Thanks for coming over today. I hope your daughter feels better soon. Just wanted to let you know there’s no need to come by tomorrow. thanks again.

Also, we found some rat droppings in my daughter’s bedroom, likely from when the inspector checked the attic. We were fine with the team spending a few hours in the house today, but we expected more care in situations like this. The area should have been cleaned before they left, or at the very least, we should have been informed so my wife could keep our toddler out of the room.

Please make sure they’re more mindful about issues like this during any future visits while we’re still here.
So sorry about that!   I'll let the owner know
 Thursday, May 1 · 6:49 AM 
The landlords are adamant about the June 15 Move out date,   what can we do to help facilitate  this? 
This is due to the importance  of the timing of the market  for the clients
 Sunday, May 4 · 12:16 PM 
Hi there, 
I'm sorry for my late response,

As I mentioned I had an extremely busy week,
Working about 14 hours these last few days, I barely got the chance to do anything,
 Tuesday, May 6 · 6:41 PM 
Hi Christina,

We began searching for a new place as soon as we were informed about the upcoming sale, but the rental market in the area hasn’t been very promising for our budget and needs.

When we moved in, our intention was to stay long term, and we’ve invested both emotionally and financially in making this our home. On top of that, I have to take unpaid time off work to search for housing and prepare for the move.

Given these challenges, we believe that a relocation support payment equal to two months’ rent would be a fair and reasonable request to help facilitate the transition and allow us to move more quickly.

Please pass this along to the landlord. we’re hoping to find a solution that works for both parties.

Thank you
Hi Ako,

 The landlords  are exempt from any payment to tenant from move out.   The property is a house and not an apartment building. They also are not a corporation. 
I've attached their just cause and rent cap exemption on this
The landlords would want the property vacant,  I served the notice of termination.
They would prefer an amicable vacancy of their property and avoid legal measures if possible. 
Does this mean you do not intend to move out by the 60 day notice move out period? 
Thank you for sending this, 
I trust your professional advice,
I have no intentions of making the case complicated,
No, of course not

We don't have any intention in complicating the case, 

If we find a good place, we can even move out sooner,
 Wednesday, May 7 · 7:51 AM 
Good morning,

The landlords  have nor received May rent.  They did want to let you know they are in financial need too and this are selling the house. 


Please advise in regards to May rent.
Good morning,

The landlords  have not received May rent.  They did want to let you know they are in financial need too and thus are selling the house. 


Please advise in regards to May rent.
 Wednesday, May 7 · 1:13 PM 
Hello Kristine,

Sure! I am sorry about the delay, 
I wasn't sure of how long we will stay here, 
i will deposit the first half today, and once we agreed on the last day, I will pay the rest, 
hope that's OK with them
also, can we get the confirmation of what day do they want the property empty? we can do it at the end of May, or mid June, 
what ever they do prefer 
please let me know
June 15 is the date they would want it vacant
oh ok! so, not sooner? I thought they wanted to have it ready for the market sooner, 
They wanted to stick to the date of end of lease
Thanks
 Wednesday, May 7 · 5:15 PM 
Hi can full rent be paid today?  Thanks
It's already closed after 5,
I'll do it first thing in the morning, 
Ok thank you
 I was just not sure if it would be half a month or the full month,
Or pre rated for mid May and June
Full month. For June is half a month
Sure
 Thursday, May 8 · 12:57 AM 
So, I owed $15 from April,
and also I called the pest control to cancel the agreement, not 12 months--< just 10 month
We have paid 5, just 5 more,
Which will be 5*55=275

---
Adding it all:
4190
+15
-275
=
3930
I had to pay a fee for an early termination,
Which is ok, 

I also paid a similar fee for pest control during 2023-24,

I'm glad that the inspector didn't raised an it about the pest
- or at least as much as I'm aware of-
 Friday, May 9 · 5:06 PM 
Unfortunately, I was only able to pay 3000 right now,
I'll pay the rest, plus any additional late fee, on Wednesday,
**
So sorry about that, I had an unexpected issue with my vehicle and had to pay $1100 out of pocket for the repair, and it will take time to get it back from the insurance,
***
Please let the landlord know that it was completely out of my control,
And I apologize 
Ok thanks
 Saturday, May 10 · 8:15 PM 
Urgent:

Hi, 

I hope you're well. I'm reaching out to report an urgent issue with the drainage/sewage system at the property. It looks like toilet sewage is backing up through a pipe and surfacing in the backyard — there's visible waste, and it's quite unsanitary and unpleasant.

Could you please arrange for someone to inspect and resolve this as soon as possible? Thank you.
 Sunday, May 11 · 10:33 AM 
Hi yes!   I'll call the same plumber
Tomorrow 8-10am  service Pros Plumber
Will this work?
Sure, 
Thank you for your quick response 
And happy mother's day! 💐
Happy Mothers Day to Neda!
❤️
 Monday, May 12 · 8:02 AM 
Your appointment with Service Pros Plumbers, Inc. has been scheduled for Monday May 12 2025 between 8:00 AM & 10:00 AM at 1655 Wendy Drive, Pleasant Hill, CA 94523 USA. To make any changes, call (925) 753-5600
Thank you, 
 Monday, May 12 · 9:37 AM 
The plumber is here, thanks
This morning 🤦🙈
431
So leak from sky light 
 Monday, May 12 · 2:56 PM 
Hi any issues with windows still or is this taken care of please send Pic if work needed 
 Monday, May 12 · 4:42 PM 
It's ok for now, I guess ,
The sky light,
 Tuesday, May 13 · 10:57 AM 
Would you mind asking the owner if he wants the refrigerator and microwave or not?
It will help to plan to sell them, if he is not interested,
Thanks
What is the price for the fridge? 
I can ask him
Sure, 
The new one is around 750, near 800 with tax,
The open box is at around 550,
We have it for 500,
Please send photo and details
$550
I thought you said 500
Sure, 
The new one is around 750, near 800 with tax,
The open box is at around 550,
We have it for 500,
Let me know so I can relay the message properly.  Thx
My mistake,
I misheard it from Neda,

The open box in OK condition is 550,
The open box with excellent is 650,
And there is nothing available at the moment,
Ok so 550? 500?
We have it on Facebook marketplace for 550,
But up to you 
Not a big deal, whatever you suggest 
Ok got it ill let them know and get back to you
👍
Sorry I first let them know 500 which is what I thought you wanted
 Tuesday, May 13 · 2:05 PM 
No problem, it's ok
 Wednesday, May 28 · 6:49 PM 
Would you mind checking if the owner wants the refrigerator or not? 
Thanks
 Thursday, May 29 · 6:55 PM 
Yes for fridge for 500.   Will you be moving out on time?
Yes, June 15th, right
Thanks so, I'll remove the ad for the fridge 
Ok thanks
 Friday, May 30 · 6:09 PM 
So, should I sign anything or are we good?
Also, for the fridge, do they want to pay or deduct it from last month's rent?
I also have a new microwave, if they are interested, 
I can send the price and details,
Please advice
 Wednesday, Jun 4 · 4:32 PM 
Please let me know, the details 
--+
Also when I can expect my deposit, because I need it for my new location and also the cost of moving,
So it will help to plan accordingly,
 Wednesday, Jun 4 · 6:19 PM 
21 days after move out for deposit
Thanks
And for the rent and refrigerator?
Deduct 500 fron rent for fridge 
👍
 Friday, Jun 13 · 8:34 AM 
Is it ok to have cleaners in the house on Monday June 16th,
Since they don't work on weekend
 Friday, Jun 13 · 11:13 AM 
Yes Monday is fine for cleaning.   Thank you
 Friday, Jun 13 · 12:21 PM 
As I know there will be professional painter at the house soon do we need to cover the holes on the wall from hanging stuff or can we leave it ton them? 
 Friday, Jun 13 · 3:06 PM 
I would patch
 Sunday, Jun 15 · 5:56 PM 
Hi how can we get keys?
Hi, 
The cleaners will be there tomorrow,
I can leave the key on the kitchen table,

Good?
 Sunday, Jun 15 · 8:35 PM 
What time will cleaners be there and finish?   
I have to ask my wife,
Probably around noon or early afternoon 
I can be there at noon
I can inform you when it's done
 Monday, Jun 16 · 11:20 AM 
The cleaners will arrive around 1  pm and they need about two hours,
 Monday, Jun 16 · 12:35 PM 
Ok thanks its think i can be there at about 4pm if that works
Good, when you leave give me a heads up and I can be there in 10 minutes or so s
 Monday, Jun 16 · 6:22 PM 
Hi can I meet w you in 30 mins?
Eta 638
I got a stop at ace hardware and will meet you there
Ok
 Thursday, Jun 26 · 1:25 PM 
Hello! 

All good with the landlord?
I wanted to check if I can collect some mail?
USPS has not yet approved my address change,

Also, do u have my new address?
 Thursday, Jun 26 · 3:44 PM 
Please do send it
 Thursday, Jun 26 · 8:33 PM 
85 Cleaveland Rd
#439
Pleasant Hill CA, 94523
BTW, just out of curiosity, I had my bike locked at the corner of the front yard,
I went today to pick it up and it wasn't there, 

If the owner or his contractor may know anything about it?

Thanks
 Thursday, Jun 26 · 11:13 PM 
Ill ask
👍
 Saturday, Jun 28 · 8:39 AM 
Realtor said it was there locked for more than a week. And when he came by it was no longer there 
What is your mailing address for your deposit check?   Also the landlords would like the box for fridge removed from the garage please. 
Can you please send us a receipt for cleaning
Got it
85 Cleaveland Rd
#439
Pleasant Hill CA, 94523
Thanks 
Sure, 
I thought since they bought the fridge, they may want it, 

I can do it Monday
I didn't understand it, would you elaborate? 
The landlords  saying they had to pay for additional cleaning
 Saturday, Jun 28 · 4:59 PM 
So, It's still not clear to me, 
He wants to see the receipt to see if I had professional cleaners? 

And what part of the house did it need additional cleaning? Because we walked to the house together, and I think you even recorded a video, 
 Saturday, Jun 28 · 8:51 PM 
I did unsure why they did an additional cleaning. Maybe drawers? Cabinets?   I sent the video.
👍
 Monday, Jun 30 · 7:40 PM 
Please update me, 

****

Also, is the owner in town, if I want to remove the fridge box? Or just stop by and talk to the realtor?
 Sunday · 9:48 PM 
Do you have zelle? Or wiring info
 Monday · 11:45 AM 
Hi would need to send this today
Hello
Sorry to miss your call
Yes, what's is this about?
ako.heidari@gmail.com
Sorry need to zelle back deposit 
Sure
They shall send today
Do you prefer a check to be mailed or zelle?
Is this the full amount or is there a deduction 
 Monday · 3:32 PM 
There were a few latest and I believe May was short.  MARCH there was a deduction for the pest services but I didnt get the bill.  
Let me send you all the recipes 

Thanks
Ill have them send what they have for now if sent earlier I can have them send that too.  
For the late fees I thought they mentioned it's ok, but look like it's going to be deducted now?
For the pest control  what was the total amount?   
They waived sept late fee.  I dont remember if they agreed to waive any other fees? Please let me know 
If I sent you a notice that the late fee was waived for any other month please  let me know
Sure, let me give you the exact number for the pest control 
For the late fees, I have text as well,
I'll send it tonight 
Thanks
 Monday · 8:59 PM 
Hi please do send over texts and i can amend for you.   The landlord has sent the portion from their records but can send more if you amend.  
8:59 PM
